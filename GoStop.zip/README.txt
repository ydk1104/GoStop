The idea of this game comes from the "Can't Stop"
If you don't know the rule of this game, read "Game Rule.txt".

Note that you MUST read "Game Play.txt" before you start game.
And then, you may open "GoStop.exe" to play.
Have Fun!